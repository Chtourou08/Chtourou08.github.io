 <nav class="navbar navbar-light navbar-expand-md navigation-clean-button">
          <div class="container"><a class="navbar-brand" href="../index.php">Chedly's Blog &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</a><button data-toggle="collapse" class="navbar-toggler"
                                                                                                                                                                                                                                                                      data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
              <div class="collapse navbar-collapse" id="navcol-1">
                  <ul class="nav navbar-nav mr-auto">
                      <li class="nav-item" role="presentation">
                        <a class="nav-link" href="mailto:chedly.chtourou@gmail.com">Contact</a>
                      </li>
                      <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Articles</a>
                        <div class="dropdown-menu" role="menu">
                            <a class="dropdown-item" role="presentation" href="Moments.html">Moments</a>
                            <a class="dropdown-item" role="presentation" href="Let-s-talk-about-yourself.html">Let's talk about yourself</a>
                            <a class="dropdown-item" role="presentation" href="my-experience-with-cryptocurrency.php">My experience with Cryptocurrency’s website spam</a>
                            <a class="dropdown-item" role="presentation" href="ds.html">Disappointment :)</a>
                        </div>
                    </li>
                      <li class="nav-item" role="presentation"><a class="nav-link" href="articles/about-me.php">About me</a></li>
                  </ul>
              </div>
          </div>
        </nav>