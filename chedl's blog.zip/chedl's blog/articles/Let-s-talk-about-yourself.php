<!DOCTYPE html>
<html>
        <head>
            <meta name="twitter:title" content="Chedly Chtourou">
            <meta property="og:type" content="website">
            <meta name="twitter:card" content="summary">
                <link rel="icon" type="image/jpeg" sizes="960x960" href="/assets/img/17022070_821728484649484_2788838060955535329_n.jpg?h=af8ec98528faab06726d2b7456f5ca82">
                <link rel="icon" type="image/jpeg" sizes="960x960" href="/assets/img/17022070_821728484649484_2788838060955535329_n.jpg?h=af8ec98528faab06726d2b7456f5ca82">
                <link rel="icon" type="image/jpeg" sizes="960x960" href="/assets/img/17022070_821728484649484_2788838060955535329_n.jpg?h=af8ec98528faab06726d2b7456f5ca82">
                <link rel="icon" type="image/jpeg" sizes="960x960" href="/assets/img/17022070_821728484649484_2788838060955535329_n.jpg?h=af8ec98528faab06726d2b7456f5ca82">
                <link rel="icon" type="image/jpeg" sizes="960x960" href="/assets/img/17022070_821728484649484_2788838060955535329_n.jpg?h=af8ec98528faab06726d2b7456f5ca82">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
                <link rel="manifest" href="/manifest.json?h=7710d1a7bfb8c00805ce1d9148010065">
                <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
                <link rel="stylesheet" href="/assets/css/styles.min.css?h=3226f8920f16e2f5b2a8e6a650642676">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">
            <title herf="/index.html">Chedly's Blog</title>
            <script data-ad-client="ca-pub-5410825261942950" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>Let’s talk about yourself!</title>
                <style>
                  * {
                  font-family: Georgia, Cambria, "Times New Roman", Times, serif;
                     }
                 html, body {
                    margin: 0;
                   padding: 0;
                  }
                h1 {
                 font-size: 50px;
                 margin-bottom: 17px;
                 color: #333;
                     }
                h2 {
                 font-size: 24px;
                 line-height: 1.6;
                 margin: 30px 0 0 0;
                 margin-bottom: 18px;
                 margin-top: 33px;
                 color: #333;
                    }
                h3 {
                 font-size: 30px;
                 margin: 10px 0 20px 0;
                 color: #333;
                    }
                header {
                 width: 640px;
                 margin: auto;
                      }
                section {
                 width: 640px;
                 margin: auto;
                      }
                section p {
                 margin-bottom: 27px;
                 font-size: 20px;
                 line-height: 1.6;
                 color: #333;
                         }
                section img {
                 max-width: 640px;
                         }
               footer {
                padding: 0 20px;
                margin: 50px 0;
                text-align: center;
                font-size: 12px;
                    }
                .aspectRatioPlaceholder {
                max-width: auto !important;
                max-height: auto !important;
                    }
                .aspectRatioPlaceholder-fill {
                padding-bottom: 0 !important;
                    }
                header,
                section[data-field=subtitle],
                section[data-field=description] {
                display: none;
                    }
          </style>
           <script data-ad-client="ca-pub-5410825261942950" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-135961896-4"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-135961896-4');
    </script>
        </head>
    <body>
        <div class="container">
          <hr>
        </div>
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-button">
          <div class="container"><a class="navbar-brand" href="../index.php">Chedly's Blog &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</a><button data-toggle="collapse" class="navbar-toggler"
                                                                                                                                                                                                                                                                      data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
              <div class="collapse navbar-collapse" id="navcol-1">
                  <ul class="nav navbar-nav mr-auto">
                      <li class="nav-item" role="presentation"><a class="nav-link" href="mailto:chedly.chtourou@gmail.com">Contact</a></li>
                      <li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">Articles</a>
                          <div class="dropdown-menu" role="menu">
                              <a class="dropdown-item" role="presentation" href="Moments.html">Moments</a>
                              <a class="dropdown-item" role="presentation" href="Let-s-talk-about-yourself.html">Let's talk about yourself</a>
                              <a class="dropdown-item" role="presentation" href="my-experience-with-cryptocurrency.php">My experience with Cryptocurrency’s website spam</a>
                              <a class="dropdown-item" role="presentation" href="ds.html">Disappointment :)</a>
                          </div>
                      </li>
                      <li class="nav-item" role="presentation"><a class="nav-link" href="aboutme.html">About me</a></li>
                  </ul>
              </div>
          </div>
        </nav>
     <article class="h-entry">
     <header>
          <h1 class="p-name">Let’s talk about yourself!!</h1>
     </header>
     <section data-field="subtitle" class="p-summary">
          Trying to get in touch with someone else is a way to express your sadness. Sometimes feelings make you confused about yourself.
     </section>
     <section data-field="body" class="e-content">
          <section name="c241" class="section section--body section--first section--last"><div class="section-divider"><hr class="section-divider"></div><div class="section-content"><div class="section-inner sectionLayout--insetColumn"><h3 name="5cf3" id="5cf3" class="graf graf--h3 graf--leading graf--title">Let’s talk about yourself!!</h3><p name="1545" id="1545" class="graf graf--p graf-after--h3">Trying to get in touch with someone else is a way to express your sadness. Sometimes feelings make you confused about yourself.</p><figure name="98dc" id="98dc" class="graf graf--figure graf-after--p"><div class="aspectRatioPlaceholder is-locked" style="max-width: 700px; max-height: 933px;"><div class="aspectRatioPlaceholder-fill" style="padding-bottom: 133.29999999999998%;"></div><img class="graf-image" data-image-id="1*JmNcj6PAR_LuJHET0oyw1Q@2x.jpeg" data-width="2448" data-height="3264" src="https://cdn-images-1.medium.com/max/800/1*JmNcj6PAR_LuJHET0oyw1Q@2x.jpeg"></div></figure><p name="96c0" id="96c0" class="graf graf--p graf-after--figure">You can’t even understand what exactly you’re looking for. Maybe you’re looking for someone cares about you or maybe you just want to avoid being lonely. But this is not the problem, the real one is what you will lose if you keep thinking like this, your identity !!</p><figure name="24bf" id="24bf" class="graf graf--figure graf-after--p"><div class="aspectRatioPlaceholder is-locked" style="max-width: 700px; max-height: 933px;"><div class="aspectRatioPlaceholder-fill" style="padding-bottom: 133.29999999999998%;"></div><img class="graf-image" data-image-id="1*ajYPfQuKwAv_AIcrfzEvRw@2x.jpeg" data-width="4896" data-height="6528" src="https://cdn-images-1.medium.com/max/800/1*ajYPfQuKwAv_AIcrfzEvRw@2x.jpeg"></div></figure><p name="ee2b" id="ee2b" class="graf graf--p graf-after--figure">Let’s try to analyse what’s going on, trying to be close to other people is actually something can’t happen that easily because if people don’t accept you as you are, so they will not accept you with something that not showing your Personality as a human being. Even if you succeed to attract people to hang out with you by changing your habits, the activities you’re doing and your principles, you will not feel happy with this new person that you create!! And also they will not gonna stay that much close to you in the future 😵😵 I know that you’re probably saying that this article is without sense but believe me you will feel it after going out with this new friends !! First they will start making excuses to avoid you and after that they will disappear 😒😒</p><figure name="7884" id="7884" class="graf graf--figure graf-after--p"><div class="aspectRatioPlaceholder is-locked" style="max-width: 700px; max-height: 933px;"><div class="aspectRatioPlaceholder-fill" style="padding-bottom: 133.29999999999998%;"></div><img class="graf-image" data-image-id="1*uF-8VsjqCZ0Z6E63a9lESA@2x.jpeg" data-width="4896" data-height="6528" src="https://cdn-images-1.medium.com/max/800/1*uF-8VsjqCZ0Z6E63a9lESA@2x.jpeg"></div></figure><p name="b10f" id="b10f" class="graf graf--p graf-after--figure">You’re showing someone that not represent what you really are!!</p><p name="dbf0" id="dbf0" class="graf graf--p graf-after--p">So, what’s the solution buddy?? You’re thinking there is no other way to achieve your goal??</p><p name="18c3" id="18c3" class="graf graf--p graf-after--p">I don’t think so, you don’t have to look for someone else to listen to your stupid thoughts or to discuss your crazy ideas. You already have someone to do that, you have yourself!!</p><p name="9e5a" id="9e5a" class="graf graf--p graf-after--p">If you can’t share this stuffs with yourself so who the hell you can share it with others ?? And what’s the importance of that for you ??and who you can manage to make it really happen in the future?? Come on, be honest with yourself !! Sometimes giving the best questions is better than giving answers 😉 and that’s what I just did 😇but don’t worry I will give you a hint !! Let’s try to say it in a different way, your best friend and your best partner is not in any other place. You’re don’t have to search too much because you’re looking at him every time you use the mirror, I’m talking about yourself smart guy !!</p><p name="1870" id="1870" class="graf graf--p graf-after--p graf--trailing">Be yourself, love yourself and share everything with yourself and you feel happiness everywhere in the air trust me :D</p></div></div></section>
     </section>
             <footer>  
                <p>By <a href="https://medium.com/@chedly.chtourou" class="p-author h-card">chtourou chedly</a> on <a href="https://medium.com/p/a0ea03801baf">
                    <time class="dt-published" datetime="2019-06-05T00:05:55.560Z">June 5, 2019</time></a>.</p> 
                <p><a href="https://medium.com/@chedly.chtourou/lets-talk-about-yourself-a0ea03801baf" class="p-canonical">Canonical link</a></p></footer>
         </article>
    </body>
</html>
